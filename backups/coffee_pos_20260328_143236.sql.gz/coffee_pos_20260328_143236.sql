--
-- PostgreSQL database dump
--

\restrict UuCmINIfrXDBcb9hKbu5NbUsSJecSNdfTFjnJuDSHCe0WPhAVf0FFVagVxWUSL5

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ingredients; Type: TABLE; Schema: public; Owner: pos_user
--

CREATE TABLE public.ingredients (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    unit character varying(20) NOT NULL,
    current_stock numeric(12,3) NOT NULL,
    min_stock_level numeric(12,3) NOT NULL,
    avg_unit_cost numeric(12,2) NOT NULL,
    last_updated timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ingredients OWNER TO pos_user;

--
-- Name: COLUMN ingredients.avg_unit_cost; Type: COMMENT; Schema: public; Owner: pos_user
--

COMMENT ON COLUMN public.ingredients.avg_unit_cost IS '加權平均單價 (WAC)';


--
-- Name: ingredients_id_seq; Type: SEQUENCE; Schema: public; Owner: pos_user
--

CREATE SEQUENCE public.ingredients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ingredients_id_seq OWNER TO pos_user;

--
-- Name: ingredients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pos_user
--

ALTER SEQUENCE public.ingredients_id_seq OWNED BY public.ingredients.id;


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: pos_user
--

CREATE TABLE public.invoices (
    id integer NOT NULL,
    order_id bigint NOT NULL,
    inv_no character varying(10),
    random_no character varying(4),
    buyer_ubn character varying(8),
    carrier_type character varying(10),
    carrier_id character varying(64),
    status character varying(20) NOT NULL,
    issued_at timestamp with time zone
);


ALTER TABLE public.invoices OWNER TO pos_user;

--
-- Name: COLUMN invoices.inv_no; Type: COMMENT; Schema: public; Owner: pos_user
--

COMMENT ON COLUMN public.invoices.inv_no IS '電子發票號碼，例如 AB12345678';


--
-- Name: COLUMN invoices.random_no; Type: COMMENT; Schema: public; Owner: pos_user
--

COMMENT ON COLUMN public.invoices.random_no IS '隨機碼 (4位數)';


--
-- Name: COLUMN invoices.buyer_ubn; Type: COMMENT; Schema: public; Owner: pos_user
--

COMMENT ON COLUMN public.invoices.buyer_ubn IS '買方統一編號（公司戶）';


--
-- Name: COLUMN invoices.carrier_type; Type: COMMENT; Schema: public; Owner: pos_user
--

COMMENT ON COLUMN public.invoices.carrier_type IS '載具類型：3J0002=手機條碼 / CQ0001=自然人憑證';


--
-- Name: COLUMN invoices.carrier_id; Type: COMMENT; Schema: public; Owner: pos_user
--

COMMENT ON COLUMN public.invoices.carrier_id IS '載具識別碼';


--
-- Name: COLUMN invoices.status; Type: COMMENT; Schema: public; Owner: pos_user
--

COMMENT ON COLUMN public.invoices.status IS 'OPEN / CANCELLED / DONATED';


--
-- Name: invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: pos_user
--

CREATE SEQUENCE public.invoices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.invoices_id_seq OWNER TO pos_user;

--
-- Name: invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pos_user
--

ALTER SEQUENCE public.invoices_id_seq OWNED BY public.invoices.id;


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: pos_user
--

CREATE TABLE public.order_items (
    id bigint NOT NULL,
    order_id bigint NOT NULL,
    product_id integer NOT NULL,
    quantity integer NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    subtotal numeric(12,2) NOT NULL
);


ALTER TABLE public.order_items OWNER TO pos_user;

--
-- Name: COLUMN order_items.unit_price; Type: COMMENT; Schema: public; Owner: pos_user
--

COMMENT ON COLUMN public.order_items.unit_price IS '下單當下的售價快照，避免商品改價影響歷史訂單';


--
-- Name: order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: pos_user
--

CREATE SEQUENCE public.order_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.order_items_id_seq OWNER TO pos_user;

--
-- Name: order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pos_user
--

ALTER SEQUENCE public.order_items_id_seq OWNED BY public.order_items.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: pos_user
--

CREATE TABLE public.orders (
    id bigint NOT NULL,
    status character varying(20) NOT NULL,
    total_amount numeric(12,2) NOT NULL,
    tax_amount numeric(12,2) NOT NULL,
    payment_method character varying(20),
    note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone
);


ALTER TABLE public.orders OWNER TO pos_user;

--
-- Name: COLUMN orders.status; Type: COMMENT; Schema: public; Owner: pos_user
--

COMMENT ON COLUMN public.orders.status IS 'PENDING / COMPLETED / CANCELLED / REFUNDED';


--
-- Name: COLUMN orders.payment_method; Type: COMMENT; Schema: public; Owner: pos_user
--

COMMENT ON COLUMN public.orders.payment_method IS 'CASH / CARD / LINEPAY / JKOPAY';


--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: pos_user
--

CREATE SEQUENCE public.orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.orders_id_seq OWNER TO pos_user;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pos_user
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: product_bom; Type: TABLE; Schema: public; Owner: pos_user
--

CREATE TABLE public.product_bom (
    id integer NOT NULL,
    product_id integer NOT NULL,
    ingredient_id integer NOT NULL,
    qty_required numeric(12,3) NOT NULL
);


ALTER TABLE public.product_bom OWNER TO pos_user;

--
-- Name: COLUMN product_bom.qty_required; Type: COMMENT; Schema: public; Owner: pos_user
--

COMMENT ON COLUMN public.product_bom.qty_required IS '製作 1 份商品所需原料用量';


--
-- Name: product_bom_id_seq; Type: SEQUENCE; Schema: public; Owner: pos_user
--

CREATE SEQUENCE public.product_bom_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.product_bom_id_seq OWNER TO pos_user;

--
-- Name: product_bom_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pos_user
--

ALTER SEQUENCE public.product_bom_id_seq OWNED BY public.product_bom.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: pos_user
--

CREATE TABLE public.products (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    category character varying(50),
    price numeric(10,2) NOT NULL,
    barcode character varying(50),
    is_active boolean NOT NULL,
    tax_type character varying(10) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.products OWNER TO pos_user;

--
-- Name: COLUMN products.tax_type; Type: COMMENT; Schema: public; Owner: pos_user
--

COMMENT ON COLUMN public.products.tax_type IS 'TAX=應稅 / ZERO=零稅率 / EXEMPT=免稅';


--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: pos_user
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.products_id_seq OWNER TO pos_user;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pos_user
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: stock_transactions; Type: TABLE; Schema: public; Owner: pos_user
--

CREATE TABLE public.stock_transactions (
    id bigint NOT NULL,
    ingredient_id integer NOT NULL,
    transaction_type character varying(20) NOT NULL,
    quantity_change numeric(12,3) NOT NULL,
    unit_cost numeric(12,2),
    order_id bigint,
    note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.stock_transactions OWNER TO pos_user;

--
-- Name: COLUMN stock_transactions.transaction_type; Type: COMMENT; Schema: public; Owner: pos_user
--

COMMENT ON COLUMN public.stock_transactions.transaction_type IS 'IN=進貨 / OUT_BOM=BOM扣減 / ADJUST=手動調整 / WASTE=耗損';


--
-- Name: COLUMN stock_transactions.quantity_change; Type: COMMENT; Schema: public; Owner: pos_user
--

COMMENT ON COLUMN public.stock_transactions.quantity_change IS '正值=增加，負值=扣減';


--
-- Name: COLUMN stock_transactions.unit_cost; Type: COMMENT; Schema: public; Owner: pos_user
--

COMMENT ON COLUMN public.stock_transactions.unit_cost IS '進貨時的單位成本，用於 WAC 計算';


--
-- Name: COLUMN stock_transactions.order_id; Type: COMMENT; Schema: public; Owner: pos_user
--

COMMENT ON COLUMN public.stock_transactions.order_id IS 'BOM扣減時關聯的訂單';


--
-- Name: stock_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: pos_user
--

CREATE SEQUENCE public.stock_transactions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stock_transactions_id_seq OWNER TO pos_user;

--
-- Name: stock_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pos_user
--

ALTER SEQUENCE public.stock_transactions_id_seq OWNED BY public.stock_transactions.id;


--
-- Name: ingredients id; Type: DEFAULT; Schema: public; Owner: pos_user
--

ALTER TABLE ONLY public.ingredients ALTER COLUMN id SET DEFAULT nextval('public.ingredients_id_seq'::regclass);


--
-- Name: invoices id; Type: DEFAULT; Schema: public; Owner: pos_user
--

ALTER TABLE ONLY public.invoices ALTER COLUMN id SET DEFAULT nextval('public.invoices_id_seq'::regclass);


--
-- Name: order_items id; Type: DEFAULT; Schema: public; Owner: pos_user
--

ALTER TABLE ONLY public.order_items ALTER COLUMN id SET DEFAULT nextval('public.order_items_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: pos_user
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: product_bom id; Type: DEFAULT; Schema: public; Owner: pos_user
--

ALTER TABLE ONLY public.product_bom ALTER COLUMN id SET DEFAULT nextval('public.product_bom_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: pos_user
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: stock_transactions id; Type: DEFAULT; Schema: public; Owner: pos_user
--

ALTER TABLE ONLY public.stock_transactions ALTER COLUMN id SET DEFAULT nextval('public.stock_transactions_id_seq'::regclass);


--
-- Data for Name: ingredients; Type: TABLE DATA; Schema: public; Owner: pos_user
--

COPY public.ingredients (id, name, unit, current_stock, min_stock_level, avg_unit_cost, last_updated) FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: pos_user
--

COPY public.invoices (id, order_id, inv_no, random_no, buyer_ubn, carrier_type, carrier_id, status, issued_at) FROM stdin;
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: pos_user
--

COPY public.order_items (id, order_id, product_id, quantity, unit_price, subtotal) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: pos_user
--

COPY public.orders (id, status, total_amount, tax_amount, payment_method, note, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: product_bom; Type: TABLE DATA; Schema: public; Owner: pos_user
--

COPY public.product_bom (id, product_id, ingredient_id, qty_required) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: pos_user
--

COPY public.products (id, name, category, price, barcode, is_active, tax_type, created_at) FROM stdin;
\.


--
-- Data for Name: stock_transactions; Type: TABLE DATA; Schema: public; Owner: pos_user
--

COPY public.stock_transactions (id, ingredient_id, transaction_type, quantity_change, unit_cost, order_id, note, created_at) FROM stdin;
\.


--
-- Name: ingredients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pos_user
--

SELECT pg_catalog.setval('public.ingredients_id_seq', 1, false);


--
-- Name: invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pos_user
--

SELECT pg_catalog.setval('public.invoices_id_seq', 1, false);


--
-- Name: order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pos_user
--

SELECT pg_catalog.setval('public.order_items_id_seq', 1, false);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pos_user
--

SELECT pg_catalog.setval('public.orders_id_seq', 1, false);


--
-- Name: product_bom_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pos_user
--

SELECT pg_catalog.setval('public.product_bom_id_seq', 1, false);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pos_user
--

SELECT pg_catalog.setval('public.products_id_seq', 1, false);


--
-- Name: stock_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pos_user
--

SELECT pg_catalog.setval('public.stock_transactions_id_seq', 1, false);


--
-- Name: ingredients ingredients_pkey; Type: CONSTRAINT; Schema: public; Owner: pos_user
--

ALTER TABLE ONLY public.ingredients
    ADD CONSTRAINT ingredients_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_inv_no_key; Type: CONSTRAINT; Schema: public; Owner: pos_user
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_inv_no_key UNIQUE (inv_no);


--
-- Name: invoices invoices_order_id_key; Type: CONSTRAINT; Schema: public; Owner: pos_user
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_order_id_key UNIQUE (order_id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: pos_user
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: pos_user
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: pos_user
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: product_bom product_bom_pkey; Type: CONSTRAINT; Schema: public; Owner: pos_user
--

ALTER TABLE ONLY public.product_bom
    ADD CONSTRAINT product_bom_pkey PRIMARY KEY (id);


--
-- Name: products products_barcode_key; Type: CONSTRAINT; Schema: public; Owner: pos_user
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_barcode_key UNIQUE (barcode);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: pos_user
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: stock_transactions stock_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: pos_user
--

ALTER TABLE ONLY public.stock_transactions
    ADD CONSTRAINT stock_transactions_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pos_user
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE RESTRICT;


--
-- Name: order_items order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pos_user
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pos_user
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE RESTRICT;


--
-- Name: product_bom product_bom_ingredient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pos_user
--

ALTER TABLE ONLY public.product_bom
    ADD CONSTRAINT product_bom_ingredient_id_fkey FOREIGN KEY (ingredient_id) REFERENCES public.ingredients(id) ON DELETE RESTRICT;


--
-- Name: product_bom product_bom_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pos_user
--

ALTER TABLE ONLY public.product_bom
    ADD CONSTRAINT product_bom_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: stock_transactions stock_transactions_ingredient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pos_user
--

ALTER TABLE ONLY public.stock_transactions
    ADD CONSTRAINT stock_transactions_ingredient_id_fkey FOREIGN KEY (ingredient_id) REFERENCES public.ingredients(id) ON DELETE RESTRICT;


--
-- Name: stock_transactions stock_transactions_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pos_user
--

ALTER TABLE ONLY public.stock_transactions
    ADD CONSTRAINT stock_transactions_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict UuCmINIfrXDBcb9hKbu5NbUsSJecSNdfTFjnJuDSHCe0WPhAVf0FFVagVxWUSL5

